import sys, os
from pathlib import Path

base_path = Path(__file__).parent

DSSP_path = str("dssp")
x3dna_path = str(base_path / "../software/x3dna-dssr")


def ss_snap(pdbid):
    os.system("{0} --input database/{1}/{1}.pdb -o database/{1}/pdb_dssp".format(DSSP_path, pdbid))
    os.system("{0} snap -i=database/{1}/{1}.pdb -o=database/{1}/interaction_detail > database/{1}/num_inter 2>&1".format(x3dna_path, pdbid))

def pdb_downloader(pdb_id):
    os.makedirs("database/{}".format(pdb_id), exist_ok=True)
    os.system("wget https://files.rcsb.org/download/{}.pdb -P database/{} > /dev/null".format(pdb_id, pdb_id))

def net_volume(wild, mutation):
    vol = {'A': '88.6', 'R': '173.4', 'N': '114.1', 'D': '111.1', 'C': '108.5', 'E': '138.4', 'Q': '143.8', 'G': '60.1',
           'H': '153.2', 'I': '166.7', 'L': '166.7', 'K': '168.6', 'M': '162.9', 'F': '189.9', 'P': '112.7',
           'S': '89.0', 'T': '116.1', 'W': '227.8', 'Y': '193.6', 'V': '140.0'}
    return ('{:.1f}'.format(float(vol.get(mutation, '0')) - float(vol.get(wild, '0'))))


def net_hydrophobicity(wild, mutation):
    hyd = {'A': '0', 'R': '3.71', 'N': '3.47', 'D': '2.95', 'C': '0.49', 'E': '1.64', 'Q': '3.01', 'G': '1.72',
           'H': '4.76', 'I': '-1.56', 'L': '-1.81', 'K': '5.39', 'M': '-0.76', 'F': '-2.2', 'P': '-1.52', 'S': '1.83',
           'T': '1.78', 'W': '-0.38', 'Y': '-1.09', 'V': '-0.78'}
    return ('{:.1f}'.format(float(hyd.get(mutation, '0')) - float(hyd.get(wild, '0'))))


def flexibility(wild, mutation):
    flex = {'A': '1', 'R': '81', 'N': '36', 'D': '18', 'C': '3', 'E': '54', 'Q': '108', 'G': '1', 'H': '36', 'I': '9',
            'L': '9', 'K': '81', 'M': '27', 'F': '18', 'P': '2', 'S': '3', 'T': '3', 'W': '36', 'Y': '18', 'V': '3'}
    return (int(flex.get(mutation, '0')) - int(flex.get(wild, '0')))


def mutation_hydrophobicity(wild, mutation):
    if wild in ('I', 'V', 'L', 'F', 'C', 'M', 'A', 'W'):
        if mutation in ('G', 'T', 'S', 'Y', 'P', 'H'):
            return 0
        elif mutation in ('N', 'D', 'Q', 'E', 'K', 'R'):
            return 1
        elif mutation in ('I', 'V', 'L', 'F', 'C', 'M', 'A', 'W'):
            return 2
    elif wild in ('G', 'T', 'S', 'Y', 'P', 'H'):
        if mutation in ('G', 'T', 'S', 'Y', 'P', 'H'):
            return 3
        elif mutation in ('N', 'D', 'Q', 'E', 'K', 'R'):
            return 4
        elif mutation in ('I', 'V', 'L', 'F', 'C', 'M', 'A', 'W'):
            return 5
    elif wild in ('N', 'D', 'Q', 'E', 'K', 'R'):
        if mutation in ('G', 'T', 'S', 'Y', 'P', 'H'):
            return 6
        elif mutation in ('N', 'D', 'Q', 'E', 'K', 'R'):
            return 7
        elif mutation in ('I', 'V', 'L', 'F', 'C', 'M', 'A', 'W'):
            return 8


def mutation_polarity(wild, mutation):
    if wild in ('R', 'H', 'K'):
        if mutation in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'W', 'V'):
            return 0
        elif mutation in ('R', 'H', 'K'):
            return 1
        elif mutation in ('N', 'Q', 'S', 'T', 'Y'):
            return 2
        elif mutation in ('D', 'E'):
            return 3
    elif wild in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'W', 'V'):
        if mutation in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'W', 'V'):
            return 4
        elif mutation in ('R', 'H', 'K'):
            return 5
        elif mutation in ('N', 'Q', 'S', 'T', 'Y'):
            return 6
        elif mutation in ('D', 'E'):
            return 7
    elif wild in ('N', 'Q', 'S', 'T', 'Y'):
        if mutation in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'W', 'V'):
            return 8
        elif mutation in ('R', 'H', 'K'):
            return 9
        elif mutation in ('N', 'Q', 'S', 'T', 'Y'):
            return 10
        elif mutation in ('D', 'E'):
            return 11
    elif wild in ('D', 'E'):
        if mutation in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'W', 'V'):
            return 12
        elif mutation in ('R', 'H', 'K'):
            return 13
        elif mutation in ('N', 'Q', 'S', 'T', 'Y'):
            return 14
        elif mutation in ('D', 'E'):
            return 15


def mutation_size(wild, mutation):
    if wild in ('G', 'A', 'S'):
        if mutation in ('C', 'D', 'P', 'N', 'T'):
            return 0
        elif mutation in ('E', 'V', 'Q', 'H'):
            return 1
        elif mutation in ('M', 'I', 'L', 'K', 'R'):
            return 2
        elif mutation in ('F', 'Y', 'W'):
            return 3
        elif mutation in ('G', 'A', 'S'):
            return 4
    elif wild in ('C', 'D', 'P', 'N', 'T'):
        if mutation in ('C', 'D', 'P', 'N', 'T'):
            return 5
        elif mutation in ('E', 'V', 'Q', 'H'):
            return 6
        elif mutation in ('M', 'I', 'L', 'K', 'R'):
            return 7
        elif mutation in ('F', 'Y', 'W'):
            return 8
        elif mutation in ('G', 'A', 'S'):
            return 9
    elif wild in ('E', 'V', 'Q', 'H'):
        if mutation in ('C', 'D', 'P', 'N', 'T'):
            return 10
        elif mutation in ('E', 'V', 'Q', 'H'):
            return 11
        elif mutation in ('M', 'I', 'L', 'K', 'R'):
            return 12
        elif mutation in ('F', 'Y', 'W'):
            return 13
        elif mutation in ('G', 'A', 'S'):
            return 14
    elif wild in ('M', 'I', 'L', 'K', 'R'):
        if mutation in ('C', 'D', 'P', 'N', 'T'):
            return 15
        elif mutation in ('E', 'V', 'Q', 'H'):
            return 16
        elif mutation in ('M', 'I', 'L', 'K', 'R'):
            return 17
        elif mutation in ('F', 'Y', 'W'):
            return 18
        elif mutation in ('G', 'A', 'S'):
            return 19
    elif wild in ('F', 'Y', 'W'):
        if mutation in ('C', 'D', 'P', 'N', 'T'):
            return 20
        elif mutation in ('E', 'V', 'Q', 'H'):
            return 21
        elif mutation in ('M', 'I', 'L', 'K', 'R'):
            return 22
        elif mutation in ('F', 'Y', 'W'):
            return 23
        elif mutation in ('G', 'A', 'S'):
            return 24


def mutation_hbonds(wild, mutation):
    if wild in ('R', 'W', 'K'):
        if mutation in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'V'):
            return 0
        elif mutation in ('R', 'W', 'K'):
            return 1
        elif mutation in ('N', 'Q', 'S', 'T', 'H', 'Y'):
            return 2
        elif mutation in ('D', 'E'):
            return 3
    elif wild in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'V'):
        if mutation in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'V'):
            return 4
        elif mutation in ('R', 'W', 'K'):
            return 5
        elif mutation in ('N', 'Q', 'S', 'T', 'Y', 'H'):
            return 6
        elif mutation in ('D', 'E'):
            return 7
    elif wild in ('N', 'Q', 'S', 'T', 'Y', 'H'):
        if mutation in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'V'):
            return 8
        elif mutation in ('R', 'W', 'K'):
            return 9
        elif mutation in ('N', 'Q', 'S', 'T', 'Y', 'H'):
            return 10
        elif mutation in ('D', 'E'):
            return 11
    elif wild in ('D', 'E'):
        if mutation in ('A', 'C', 'G', 'I', 'L', 'M', 'F', 'P', 'V'):
            return 12
        elif mutation in ('R', 'W', 'K'):
            return 13
        elif mutation in ('N', 'Q', 'S', 'T', 'Y', 'H'):
            return 14
        elif mutation in ('D', 'E'):
            return 15


def mutation_chemical(wild, mutation):
    if wild in ('A', 'G', 'I', 'L', 'P', 'V'):
        if mutation in ('R', 'H', 'K'):
            return 0
        elif mutation in ('N', 'Q'):
            return 1
        elif mutation in ('D', 'E'):
            return 2
        elif mutation in ('C', 'M'):
            return 3
        elif mutation in ('S', 'T'):
            return 4
        elif mutation in ('F', 'W', 'Y'):
            return 5
        elif mutation in ('A', 'G', 'I', 'L', 'P', 'V'):
            return 6
    elif wild in ('R', 'H', 'K'):
        if mutation in ('R', 'H', 'K'):
            return 7
        elif mutation in ('N', 'Q'):
            return 8
        elif mutation in ('D', 'E'):
            return 9
        elif mutation in ('C', 'M'):
            return 10
        elif mutation in ('S', 'T'):
            return 11
        elif mutation in ('F', 'W', 'Y'):
            return 12
        elif mutation in ('A', 'G', 'I', 'L', 'P', 'V'):
            return 13
    elif wild in ('N', 'Q'):
        if mutation in ('R', 'H', 'K'):
            return 14
        elif mutation in ('N', 'Q'):
            return 15
        elif mutation in ('D', 'E'):
            return 16
        elif mutation in ('C', 'M'):
            return 17
        elif mutation in ('S', 'T'):
            return 18
        elif mutation in ('F', 'W', 'Y'):
            return 19
        elif mutation in ('A', 'G', 'I', 'L', 'P', 'V'):
            return 20
    elif wild in ('D', 'E'):
        if mutation in ('R', 'H', 'K'):
            return 21
        elif mutation in ('N', 'Q'):
            return 22
        elif mutation in ('D', 'E'):
            return 23
        elif mutation in ('C', 'M'):
            return 24
        elif mutation in ('S', 'T'):
            return 25
        elif mutation in ('F', 'W', 'Y'):
            return 26
        elif mutation in ('A', 'G', 'I', 'L', 'P', 'V'):
            return 27
    elif wild in ('C', 'M'):
        if mutation in ('R', 'H', 'K'):
            return 28
        elif mutation in ('N', 'Q'):
            return 29
        elif mutation in ('D', 'E'):
            return 30
        elif mutation in ('C', 'M'):
            return 31
        elif mutation in ('S', 'T'):
            return 32
        elif mutation in ('F', 'W', 'Y'):
            return 33
        elif mutation in ('A', 'G', 'I', 'L', 'P', 'V'):
            return 34
    elif wild in ('S', 'T'):
        if mutation in ('R', 'H', 'K'):
            return 35
        elif mutation in ('N', 'Q'):
            return 36
        elif mutation in ('D', 'E'):
            return 37
        elif mutation in ('C', 'M'):
            return 38
        elif mutation in ('S', 'T'):
            return 39
        elif mutation in ('F', 'W', 'Y'):
            return 40
        elif mutation in ('A', 'G', 'I', 'L', 'P', 'V'):
            return 41
    elif wild in ('F', 'W', 'Y'):
        if mutation in ('R', 'H', 'K'):
            return 42
        elif mutation in ('N', 'Q'):
            return 43
        elif mutation in ('D', 'E'):
            return 44
        elif mutation in ('C', 'M'):
            return 45
        elif mutation in ('S', 'T'):
            return 46
        elif mutation in ('F', 'W', 'Y'):
            return 47
        elif mutation in ('A', 'G', 'I', 'L', 'P', 'V'):
            return 48


def mutation_type(wild, mutation):
    wild_lists = ['A', 'F', 'C', 'D', 'N', 'E', 'Q', 'G', 'H', 'L', 'I', 'K', 'M', 'P', 'R', 'S', 'T', 'V', 'W', 'Y']
    mutation_lists = ['A', 'F', 'C', 'D', 'N', 'E', 'Q', 'G', 'H', 'L', 'I', 'K', 'M', 'P', 'R', 'S', 'T', 'V', 'W',
                      'Y']
    label_1 = 0
    label_2 = 0
    for i in wild_lists:
        for j in mutation_lists:
            if i != j:
                label_1 += 1
                if wild == i:
                    if mutation == j and i != j:
                        label_2 = label_1
                        break
    return label_2


def mutation_ss_label(SS_LABEL):
    label = {'H': '1', 'B': '2', 'E': '3', 'G': '4', 'I': '5', 'T': '6', 'S': '7'}
    return (label.get(SS_LABEL, 0))


def mutation_ss(pdbid, chain, position, wild):
    ss_index = ['0', '1', '2', '3', '4', '5', '6', '7']
    index = 0
    ss_ratio = []
    ss_ratio_list = []
    ss = 0
    acc = 0
    phi = 0
    psi = 0
    for line in open("database/{}/pdb_dssp".format(pdbid)):
        info = line
        if info[11:12].strip() == chain and info[5:10].strip() == str(position):
            if info[13:14].strip() != wild:
                print("Wild type amino acid does not match the structure.")
                sys.exit()
            ss = mutation_ss_label(info[16:17])
            acc = info[35:38].strip()
            phi = info[103:109].strip()
            psi = info[109:115].strip()
        if info[11:12].strip() == chain and index == 1:
            ss_ratio.append(mutation_ss_label(info[16:17]))
        if info[2:10] == "#  RESID":
            index = 1
    for i in ss_index:
        ss_ratio_list.append('%.2f' % (ss_ratio.count(i) / float(len(ss_ratio))))
    del (ss_ratio_list[0])
    del (ss_ratio_list[4])  # delete 0,5 columns ,all of them are 0.
    if acc == "":
        acc = 0
    if psi == "":
        psi = 0
    if phi == "":
        phi = 0
    return (ss, acc, phi, psi, ss_ratio_list)


def snap(pdbid):
    pro = 0
    nuc = 0
    h_bonds = 0
    stack = 0
    for line in open("database/{}/num_inter".format(pdbid)):
        info = line.strip()
        if "total number of nucleotide/amino-acid contacts:" in info:
            if len(info.split()) > 2:
                nuc = info.split()[-1]
        elif "total number of phosphate/amino-acid H-bonds:" in info:
            if len(info.split()) > 2:
                pro = info.split()[-1]
        elif "total number of base/amino-acid H-bonds:" in info:
            if len(info.split()) > 2:
                h_bonds = info.split()[-1]
        elif "total number of base/amino-acid stacks:" in info:
            if len(info.split()) > 2:
                stack = info.split()[-1]
    return (nuc, pro, h_bonds, stack)


def process_sample(pdbid, chain, mutation_resid, wild_aa, mutation_aa, ph):
    if wild_aa == mutation_aa:
        print("PDB=" + pdbid, "Chain=" + chain, "Position=" + mutation_resid, "Wild=" + wild_aa,
              "Mutant=" + mutation_aa, "Please input correct mutant.")
        sys.exit()
    os.makedirs("./database", exist_ok=True)

    if pdbid not in os.listdir("./database"):
        pdb_downloader(pdbid)
        ss_snap(pdbid)

    label = []
    label.append(net_volume(wild_aa, mutation_aa))
    label.append(net_hydrophobicity(wild_aa, mutation_aa))
    label.append(flexibility(wild_aa, mutation_aa))
    label.append(mutation_hydrophobicity(wild_aa, mutation_aa))
    label.append(mutation_polarity(wild_aa, mutation_aa))
    label.append(mutation_type(wild_aa, mutation_aa))
    label.append(mutation_size(wild_aa, mutation_aa))
    label.append(mutation_hbonds(wild_aa, mutation_aa))
    label.append(mutation_chemical(wild_aa, mutation_aa))
    (ss, acc, phi, psi, ss_ratio_list) = mutation_ss(pdbid, chain, mutation_resid, wild_aa)
    label.append(acc)
    label.append(ss)
    label.append(ph)  # Change to the experimental PH you want.
    label = label + ss_ratio_list
    label.append(psi)
    label.append(phi)
    (a, b, c, d) = snap(pdbid)
    label.append(a)
    label.append(b)
    label.append(c)
    label.append(d)
    # for i in label:
    # print i,
    return label
