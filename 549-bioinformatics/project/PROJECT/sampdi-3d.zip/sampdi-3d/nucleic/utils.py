import sys, os
from pathlib import Path

base_path = Path(__file__).parent

DSSP_path = str("dssp")
x3dna_path = str(base_path / "../software/x3dna-dssr")

def ss_snap(pdbid):
    os.system("{0} --input database/{1}/{1}.pdb -o database/{1}/pdb_dssp".format(DSSP_path, pdbid))
    os.system("{0} --more -i=database/{1}/{1}.pdb -o=database/{1}/dna_detail > /dev/null 2>&1".format(x3dna_path, pdbid))
    os.system("{0} snap -i=database/{1}/{1}.pdb -o=database/{1}/interaction_detail > database/{1}/num_inter 2>&1".format(x3dna_path, pdbid))

def remove_file():
    remove_list = ["dssr-2ndstrs.bpseq", "dssr-2ndstrs.ct", "dssr-2ndstrs.dbn", "dssr-helices.pdb", "dssr-pairs.pdb",
                   "dssr-stems.pdb", "dssr-torsions.txt"]
    for name in remove_list:
        try:
            os.remove(name)
        except:
            continue

def pdb_downloader(pdb_id):
    os.makedirs("database/{}".format(pdb_id), exist_ok=True)
    os.system("wget https://files.rcsb.org/download/{}.pdb -P database/{} > /dev/null".format(pdb_id, pdb_id))

def mutation_type(wild, mutation):
    lists = ['AA', 'AT', 'AG', 'AC', 'TA', 'TT', 'TG', 'TC', 'GA', 'GT', 'GG', 'GC', 'CA', 'CT', 'CG', 'CC']
    label_1 = 0
    label_2 = 0
    for i in lists:
        for j in lists:
            if i != j:
                label_1 += 1
                if wild == i:
                    if mutation == j and i != j:
                        label_2 = label_1
                        break
    return label_2


def mismatch(wild, mutation):
    lists = ['AT', 'TA', 'GC', 'CG']
    if wild not in lists or mutation not in lists:
        return 1
    else:
        return 0


def pair_type(wild):
    if wild == "AT" or wild == "TA":
        return 1
    if wild == "GC" or wild == "CG":
        return 0
    return 2


def mutation_ss_label(SS_LABEL):
    label = {'H': '1', 'B': '2', 'E': '3', 'G': '4', 'I': '5', 'T': '6', 'S': '7'}
    return (label.get(SS_LABEL, 0))


def mutation_ss(pdbid):
    ss_index = ['0', '1', '2', '3', '4', '5', '6', '7']
    index = 0
    ss_ratio = []
    ss_ratio_list = []
    for line in open("database/{}/pdb_dssp".format(pdbid)):
        info = line
        if index == 1:
            ss_ratio.append(mutation_ss_label(info[16:17]))
        if info[2:10] == "#  RESID":
            index = 1
    for i in ss_index:
        ss_ratio_list.append('%.2f' % (ss_ratio.count(i) / float(len(ss_ratio))))
    del (ss_ratio_list[0])
    del (ss_ratio_list[4])  # delete 0,5 columns ,all of them are 0.
    return (ss_ratio_list)


def dna_par(pdbid, chain, resid, for_w, rev_w):
    index = 0
    index_1 = 0
    index_2 = 0
    bp_par = []
    bp_step = []
    bp_heli = []
    features = []
    f = open("database/{}/dna_detail".format(pdbid))
    lines = f.readlines()
    i = 0
    while i < len(lines):
        if " " + chain + ".D" + for_w + str(resid) + " " in lines[i] and ".D" + rev_w in lines[i]:
            if "bp-pars: [" in lines[i + 5]:
                for num in lines[i + 5].strip()[10:-1].split():
                    try:
                        float(num)
                        bp_par.append(num)
                    except ValueError:
                        bp_par.append(0)
            elif "step-pars:  [" in lines[i + 2]:
                for num in lines[i + 2].strip()[13:-1].split():
                    try:
                        float(num)
                        bp_step.append(num)
                    except ValueError:
                        bp_step.append(0)
                for num in lines[i + 3].strip()[13:-1].split():
                    try:
                        float(num)
                        bp_heli.append(num)
                    except ValueError:
                        bp_heli.append(0)
                break
        i = i + 1
    while len(bp_par) < 6:
        bp_par.append(0)
    while len(bp_step) < 6:
        bp_step.append(0)
    while len(bp_heli) < 6:
        bp_heli.append(0)
    features = bp_par + bp_step + bp_heli
    return (features)


def snap(pdbid):
    pro = 0
    nuc = 0
    h_bonds = 0
    stack = 0
    for line in open("database/{}/num_inter".format(pdbid)):
        info = line.strip()
        if "total number of nucleotide/amino-acid contacts:" in info:
            if len(info.split()) > 2:
                nuc = info.split()[-1]
        elif "total number of phosphate/amino-acid H-bonds:" in info:
            if len(info.split()) > 2:
                pro = info.split()[-1]
        elif "total number of base/amino-acid H-bonds:" in info:
            if len(info.split()) > 2:
                h_bonds = info.split()[-1]
        elif "total number of base/amino-acid stacks:" in info:
            if len(info.split()) > 2:
                stack = info.split()[-1]
    return (nuc, pro, h_bonds, stack)

def process_sample(pdb_id, chain, position, wild, mutant):
    if wild == mutant:
        print("Wild type is same as Mutant, please check.")
        sys.exit()
    mutation_aa_list = ['AA', 'AT', 'AG', 'AC', 'TA', 'TT', 'TG', 'TC', 'GA', 'GT', 'GG', 'GC', 'CA', 'CT', 'CG', 'CC']
    if wild not in mutation_aa_list or mutant not in mutation_aa_list:
        print("Wild type or Mutant is not DNA.")
        sys.exit()

    os.makedirs("./database", exist_ok=True)

    if pdb_id not in os.listdir("./database"):
        pdb_downloader(pdb_id)
        ss_snap(pdb_id)
        remove_file()

    label = []
    label.append(mutation_type(wild, mutant))
    label.append(mismatch(wild, mutant))
    label.append(pair_type(wild))
    label = label + mutation_ss(pdb_id)
    (a, b, c, d) = snap(pdb_id)
    label.append(a)
    label.append(b)
    label.append(c)
    label.append(d)
    label = label + dna_par(pdb_id, chain, position, wild[0], mutant[1])
    # for i in label:
    # print i,

    return label
