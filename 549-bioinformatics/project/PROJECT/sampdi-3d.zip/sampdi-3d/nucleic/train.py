import os, shutil

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler
import utils
import matplotlib.pyplot as plt
from scipy.stats import norm

train_path = "./dataset/train/"
train_filename = "D463.csv"

test_path = "./dataset/test/"
test_filename = "T227.csv"


def normalize(data):
    data = data.astype(float) / np.linalg.norm(data, axis=1).reshape(-1, 1)
    return data


def transform(dataframe, train=True):
    input = []
    output = []

    for index, row in dataframe.iterrows():
        if train:
            pdb_id = row["PDBID"]
        else:
            pdb_id = row["PDB_ID"]
        chain = row["CHAIN"]
        position = row["POSITION"]
        wild = row["WILD"]
        mutant = row["MUTANT"]

        if train:
            target = row["DDG"]
        else:
            target = row["DDM"]

        processed = utils.process_sample(pdb_id, chain, position, wild, mutant)

        processed = np.asarray([float(elem) for elem in processed])

        input.append(processed)
        output.append(target)

    #input = normalize(np.asarray(input))

    return np.asarray(input), np.asarray(output)


def load(fname):
    with open(fname, "rb") as f:
        return np.load(f)


def save(fname, obj=None):
    np.save(fname, obj)

def stats(data1, data2):
    n=10

    mean1 = np.mean(data1, axis=0)
    std1 = np.std(data1, axis=0)

    mean2 = np.mean(data2, axis=0)
    std2 = np.std(data2, axis=0)


    fig, ax = plt.subplots(nrows=n, ncols=1, figsize=(6, 15))

    for i in range(n):
        x_axis1 = np.linspace(mean1[i] - std1[i]*3, mean1[i] + std1[i]*3, 100)
        ax[i].plot(x_axis1, norm.pdf(x_axis1, mean1[i], std1[i]), label="TrainSet")

        x_axis2 = np.linspace(mean2[i] - std2[i]*3, mean2[i] + std2[i]*3, 100)
        ax[i].plot(x_axis2, norm.pdf(x_axis2, mean2[i] , std2[i]), label="TestSet")

    plt.legend()
    plt.show()
    plt.close()
def main():

    try:
        X_train = load("nuc_train_x.npy")
        y_train = load("nuc_train_y.npy")
        X_test = load("nuc_test_x.npy")
        y_test = load("nuc_test_y.npy")
    except:

        csv_data = pd.read_csv(train_path + train_filename)

        csv_data_test = pd.read_csv(test_path + test_filename)

        # convert using dssr and dssp
        X_train, y_train = transform(csv_data, train=True)

        X_test, y_test = transform(csv_data_test, train=False)

        # write to disk to save time
        #save("nuc_train_x.npy", X_train)
        #save("nuc_train_y.npy", y_train)
        #save("nuc_test_x.npy", X_test)
        #save("nuc_test_y.npy", y_test)
        utils.remove_file() # remove redundant files

    # add test set to train to check 
    # X_train = np.concatenate((X_train, X_test), axis=0)
    # y_train = np.concatenate((y_train, y_test), axis=0)
    #stats(X_train, X_test)

    transformer = RobustScaler().fit(X_train)
    X_train = transformer.transform(X_train)
    X_test = transformer.transform(X_test)

    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)

    train = xgb.DMatrix(X_train, y_train)
    val = xgb.DMatrix(X_val, y_val)
    test = xgb.DMatrix(X_test, y_test)

    # Tune parameters
    params = {
        "learning_rate": 0.05,
        "max_depth": 5,
    }

    model = xgb.train(
        params, train,
        evals=[(train, "train"), (test, "test"), (val, "validation")],
        num_boost_round=100, early_stopping_rounds=20
    )

    preds_train = model.predict(train)

    print("Train Pears. Coeff.: {}".format(
        np.corrcoef(preds_train, y_train)[0, 1])
    )

    preds_val = model.predict(val)
    print("Val Pears. Coeff.: {}".format(
        np.corrcoef(preds_val, y_val)[0, 1])
    )

    preds = model.predict(test)

    print("Test Pears. Coeff.: {}".format(
        np.corrcoef(preds, y_test)[0, 1])
    )

    model.save_model("custom.model")


if __name__ == "__main__":
    main()
