import os, shutil

import numpy as np
import pandas as pd
import xgboost as xgb

import utils


test_path = "./dataset/test/"
test_filename = "T227.csv"

def transform(dataframe, train=True):
    input = []
    output = []

    for index, row in dataframe.iterrows():
        if train:
            pdb_id = row["PDBID"]
        else:
            pdb_id = row["PDB_ID"]
        chain = row["CHAIN"]
        position = row["POSITION"]
        wild = row["WILD"]
        mutant = row["MUTANT"]

        if train:
            target = row["DDG"]
        else:
            target = row["DDM"]

        processed = utils.process_sample(pdb_id, chain, position, wild, mutant)
        input.append(processed)
        output.append(target)

    return np.asarray(input), np.asarray(output)


def load(fname):
    with open(fname, "rb") as f:
        return np.load(f)


def save(fname, obj=None):
    with open(fname, "wb+") as f:
        np.save(fname, obj)


def pred_feature(data, model_name="custom.model"):
    model = xgb.Booster(model_file=str(model_name))
    x = xgb.DMatrix(data)
    y_pred = model.predict(x)

    return y_pred


def main():

    try:
        X_test = load("nuc_test_x.npy")
        y_test = load("nuc_test_y.npy")
    except:

        csv_data = pd.read_csv(test_path + test_filename)
        X_test, y_test = transform(csv_data, train=False)

        save("nuc_test_x.npy", X_test)
        save("nuc_test_y.npy", y_test)
        utils.remove_file()

    preds = pred_feature(X_test, "./custom.model")

    print(np.corrcoef(preds, y_test)[0, 1])


if __name__ == "__main__":
    main()
